require('./test-adapter.js');
require('./extension-test.js');
require('promises-aplus-tests-phantom/lib/testFiles');
